This is a freeware font...so please enjoy!  Here's the legal stuff: 

	1. This font was created by D. Brian Weese (dbweese@gmail.com) and is FREE
		to use for PERSONAL USE ONLY.  It may NOT be used for commercial purposes
		or sold in any way.

	2. This font MAY be placed on any website (please contact me first) to make
		available for people to download, providing that proper CREDIT is given
		to me and this README.txt file is left in tact and attached.

	3. I am not and can not be held resposible for any damages incurred to any computer
		after installing and/or using this font.

	4. I designed this font completely from the ground up using Type Light 2.2.

If you use this font, send me the link!  I would love to see what you did with it.

If you like this font or have an idea for a font, let me know!  Send your mail to dbweese@gmail.com. 

Thanks,

D. Brian Weese